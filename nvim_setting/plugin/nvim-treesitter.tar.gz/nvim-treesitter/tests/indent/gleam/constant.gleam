pub const foo = 
  "bar"
