<?php

enum Test: int
{
