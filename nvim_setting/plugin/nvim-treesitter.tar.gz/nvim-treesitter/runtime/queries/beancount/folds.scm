[
  (transaction)
  (section)
] @fold
